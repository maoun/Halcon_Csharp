#!/bin/bash
exec java -jar ./SocketTest.jar java_look